﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace ClassLibrary1
{
    public class Units
    {
        public string Name { get; set; }
        public int Level { get; set; }
        public float Armor { get; set; }
        public float Energy { get; set; }
        public float Health { get; set; }
        public float Shield { get; set; }
        public float Speed { get; set; }
        public int Ability_Duration { get; set; }
        public int Ability_Effciency { get; set; }
        public int Ability_Strength { get; set; }
        public int Passive_Code { get; set; }
        public Image icon;
        public Image ills;

        public Units(Image i, Image i2)
        {
            this.icon = i;
            this.ills = i2;
        }
    }
}
