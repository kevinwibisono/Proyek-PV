﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BraveFrontier
{
    public partial class Quest : Form
    {
        public int map = 0;
        public int ministage = 0;
        public Image[] mapimg = new Image[10];
        public bool[] ministagesdone = new bool[5];
        public List<Button> btnministg1;
        public List<Button> btnministg2;
        public List<Button> btnministg3;
        public List<Button> btnministg4;
        public List<Button> btnministg5;
        public Quest()
        {
            InitializeComponent();
            this.Location = new Point(0, 0);
            this.FormBorderStyle = FormBorderStyle.None;
            btnministg1 = new List<Button>();
            btnministg2 = new List<Button>();
            btnministg3 = new List<Button>();
            btnministg4 = new List<Button>();
            btnministg5 = new List<Button>();
            mapimg[0] = Image.FromFile("bg1.png");
            mapimg[1] = Image.FromFile("bg3.png");
            mapimg[2] = Image.FromFile("bg10.png");
            mapimg[3] = Image.FromFile("bg12.png");
            mapimg[4] = Image.FromFile("bg16.png");
            for (int i = 0; i < 5; i++)
            {
                ministagesdone[0] = false;
            }
        }

        private void Quest_Load(object sender, EventArgs e)
        {
            this.BackgroundImage = mapimg[map];
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        public void nextstage()
        {
            ministage += 1;
            if (ministage > 5)
            {
                ministage = 1;
                if(map == 4)
                {
                    ministage = 5;
                    map = 4;
                }
                else
                {
                    map += 1;
                }
            }
            Invalidate();
        }
        private void Quest_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.DrawImage(Image.FromFile("btnback.jpg"), 10, 10, 50, 50);
            if(map == 0)
            {
                g.DrawString("Stage 1 :The Shire", new Font("Magneto", 15), new SolidBrush(Color.Gold), 50, 25);
            }
            else if(map == 1)
            {
                ministagesdone[0] = true;
                g.DrawString("Stage 2 : Helheim", new Font("Magneto", 15), new SolidBrush(Color.Gold), 50, 25);
            }
            else if (map == 2)
            {
                ministagesdone[1] = true;
                g.DrawString("Stage 3 : Valhalla", new Font("Magneto", 15), new SolidBrush(Color.Gold), 50, 25);
            }
            else if (map == 3)
            {
                ministagesdone[2] = true;
                g.DrawString("Stage 4 : Nidavelir", new Font("Magneto", 15), new SolidBrush(Color.Gold), 0, 25);
            }
            else if (map == 4)
            {
                ministagesdone[3] = true;
                g.DrawString("Stage 5 : Nowhere", new Font("Magneto", 15), new SolidBrush(Color.Gold), 0, 25);
            }
            this.BackgroundImage = mapimg[map];
            this.BackgroundImageLayout = ImageLayout.Stretch;
            if (ministage == 1)
            {
                g.DrawRectangle(new Pen(Color.Black), 10, 500, 100, 50);
                g.DrawString("Stage 1", new Font("Arial Black", 12), new SolidBrush(Color.Black), 25, 515);
            }
            else if(ministage == 2)
            {
                g.DrawRectangle(new Pen(Color.Black), 10, 500, 100, 50);
                g.DrawString("Stage 1", new Font("Arial Black", 12), new SolidBrush(Color.Black), 25, 515);

                g.DrawRectangle(new Pen(Color.Black), 275, 400, 100, 50);
                g.DrawString("Stage 2", new Font("Arial Black", 12), new SolidBrush(Color.Black), 290, 415);
            }
            else if (ministage == 3)
            {
                g.DrawRectangle(new Pen(Color.Black), 10, 500, 100, 50);
                g.DrawString("Stage 1", new Font("Arial Black", 12), new SolidBrush(Color.Black), 25, 515);

                g.DrawRectangle(new Pen(Color.Black), 275, 400, 100, 50);
                g.DrawString("Stage 2", new Font("Arial Black", 12), new SolidBrush(Color.Black), 290, 415);

                g.DrawRectangle(new Pen(Color.Black), 10, 300, 100, 50);
                g.DrawString("Stage 3", new Font("Arial Black", 12), new SolidBrush(Color.Black), 25, 315);
            }
            else if(ministage == 4)
            {
                g.DrawRectangle(new Pen(Color.Black), 10, 500, 100, 50);
                g.DrawString("Stage 1", new Font("Arial Black", 12), new SolidBrush(Color.Black), 25, 515);

                g.DrawRectangle(new Pen(Color.Black), 275, 400, 100, 50);
                g.DrawString("Stage 2", new Font("Arial Black", 12), new SolidBrush(Color.Black), 290, 415);

                g.DrawRectangle(new Pen(Color.Black), 10, 300, 100, 50);
                g.DrawString("Stage 3", new Font("Arial Black", 12), new SolidBrush(Color.Black), 25, 315);

                g.DrawRectangle(new Pen(Color.Black), 275, 200, 100, 50);
                g.DrawString("Stage 4", new Font("Arial Black", 12), new SolidBrush(Color.Black), 290, 215);
            }
            else if(ministage == 5)
            {
                g.DrawRectangle(new Pen(Color.Black), 10, 500, 100, 50);
                g.DrawString("Stage 1", new Font("Arial Black", 12), new SolidBrush(Color.Black), 25, 515);

                g.DrawRectangle(new Pen(Color.Black), 275, 400, 100, 50);
                g.DrawString("Stage 2", new Font("Arial Black", 12), new SolidBrush(Color.Black), 290, 415);

                g.DrawRectangle(new Pen(Color.Black), 10, 300, 100, 50);
                g.DrawString("Stage 3", new Font("Arial Black", 12), new SolidBrush(Color.Black), 25, 315);

                g.DrawRectangle(new Pen(Color.Black), 275, 200, 100, 50);
                g.DrawString("Stage 4", new Font("Arial Black", 12), new SolidBrush(Color.Black), 290, 215);

                g.DrawRectangle(new Pen(Color.Black), 10, 100, 100, 50);
                g.DrawString("Stage 5", new Font("Arial Black", 12), new SolidBrush(Color.Black), 25, 115);
            }
        }

        private void Quest_Click(object sender, EventArgs e)
        {
            
        }

        private void Quest_MouseClick(object sender, MouseEventArgs e)
        {
            Rectangle r = new Rectangle(10, 10, 50, 50);
            if(r.Contains(e.X, e.Y))
            {
                Form1 parent = (Form1)this.MdiParent;
                parent.stage = map;
                parent.ministage = ministage;
                parent.q.Close();
                parent.h = new Home();
                parent.h.MdiParent = parent;
                parent.h.Show();
                parent.h.Location = new Point(0, 0);
            }
            else
            {
                nextstage();
            }
        }
    }
}
