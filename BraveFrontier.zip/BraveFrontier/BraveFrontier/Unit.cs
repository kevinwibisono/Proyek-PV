﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BraveFrontier
{
    public partial class Unit : Form
    {
        public List<ClassLibrary1.Units> listunit;
        public ClassLibrary1.Units current;
        public string status = "menu";
        public Unit()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.None;
        }

        private void Unit_Load(object sender, EventArgs e)
        {

        }

        private void Unit_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            g.DrawImage(Image.FromFile("headerunit.jpg"), 0, 10, 390, 50);
            if (status.Equals("viewunit"))
            {
                for (int i = 0; i < listunit.Count; i++)
                {
                    g.DrawImage(listunit[i].icon, (i+1) * 50 + 50, (i+1) * 50 + 50, 75, 50);
                }
            }
            else if (status.Equals("menu"))
            {                
                g.DrawRectangle(new Pen(Color.Yellow), 40, 100, 150, 100);
                g.DrawString("View Units", new Font("Courier New", 12), new SolidBrush(Color.Yellow), 55, 115);

                g.DrawRectangle(new Pen(Color.Yellow), 205, 100, 150, 100);
                g.DrawString("Upgrade Mod", new Font("Courier New", 12), new SolidBrush(Color.Yellow), 220, 115);

                g.DrawRectangle(new Pen(Color.Yellow), 40, 215, 150, 100);
                g.DrawString("Manage Squad", new Font("Courier New", 12), new SolidBrush(Color.Yellow), 55, 230);
            }
            else if (status.Equals("viewoneunit"))
            {

            }
        }

        private void Unit_MouseClick(object sender, MouseEventArgs e)
        {

            if (status.Equals("viewunit"))
            {
                for (int i = 0; i < listunit.Count; i++)
                {
                    Rectangle r = new Rectangle((i + 1) * 50 + 50, (i + 1) * 50 + 50, 75, 50);
                    if(r.Contains(e.X, e.Y))
                    {
                        status = "";
                        Button b = new Button();

                    }
                }
            }
            if (status.Equals("menu"))
            {
                Rectangle r = new Rectangle(0, 10, 100, 50);
                Rectangle r2 = new Rectangle(40, 100, 150, 100);
                Rectangle r3 = new Rectangle(205, 100, 150, 100);
                Rectangle r4 = new Rectangle(40, 215, 150, 100);
                if (r.Contains(e.X, e.Y))
                {
                    Form1 parent = (Form1)this.MdiParent;
                    parent.u.Close();
                    parent.h = new Home();
                    parent.h.MdiParent = parent;
                    parent.h.Show();
                    parent.h.Location = new Point(0, 0);
                }
                else if (r2.Contains(e.X, e.Y))
                {
                    status = "viewunit";
                    Invalidate();
                }
                else if (r3.Contains(e.X, e.Y))
                {
                    status = "upgrade mod";
                }
                else if (r4.Contains(e.X, e.Y))
                {
                    status = "manage squad";
                }
            }
        }
    }
}
