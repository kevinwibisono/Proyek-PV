﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BraveFrontier
{
    public partial class Home : Form
    {
        List<Image> images;
        List<int> ximages;
        List<int> yimages;
        List<int> widthimg;
        List<int> heightimg;
        public Home()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.None;
            images = new List<Image>();
            ximages = new List<int>();
            yimages = new List<int>();
            widthimg = new List<int>();
            heightimg = new List<int>();
        }

        private void Home_Load(object sender, EventArgs e)
        {
            Image btnquest = Image.FromFile("btnquest.png");
            images.Add(btnquest);
            ximages.Add(100);
            yimages.Add(150);
            widthimg.Add(200);
            heightimg.Add(250);

            Image btnhome = Image.FromFile("btnhome.png");
            images.Add(btnhome);
            ximages.Add(0);
            yimages.Add(455);
            widthimg.Add(125);
            heightimg.Add(100);

            Image btnunits = Image.FromFile("btnunits.png");
            images.Add(btnunits);
            ximages.Add(127);
            yimages.Add(455);
            widthimg.Add(125);
            heightimg.Add(100);

            Image btnshop = Image.FromFile("btnshop.png");
            images.Add(btnshop);
            ximages.Add(254);
            yimages.Add(455);
            widthimg.Add(125);
            heightimg.Add(100);

            Image infoplayer = Image.FromFile("header.jpg");
            images.Add(infoplayer);
            ximages.Add(0);
            yimages.Add(0);
            widthimg.Add(390);
            heightimg.Add(100);
        }

        private void Home_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            for (int i = 0; i < images.Count; i++)
            {
                g.DrawImage(images[i], ximages[i], yimages[i], widthimg[i], heightimg[i]);
            }
        }

        private void Home_MouseClick(object sender, MouseEventArgs e)
        {
            for (int i = 0; i < images.Count; i++)
            {
                Rectangle r = new Rectangle(ximages[i], yimages[i], widthimg[i], heightimg[i]);
                if(r.Contains(e.X, e.Y))
                {
                    if(i == 0)
                    {
                        Form1 parent = (Form1)this.MdiParent;
                        parent.h.Close();
                        parent.q = new Quest();
                        parent.q.map = parent.stage;
                        parent.q.ministage = parent.ministage;
                        parent.q.MdiParent = parent;
                        parent.q.Show();
                        parent.q.Location = new Point(0, 0);
                    }
                    if (i == 2)
                    {
                        Form1 parent = (Form1)this.MdiParent;
                        parent.h.Close();
                        parent.u = new Unit();
                        parent.u.MdiParent = parent;
                        parent.u.listunit = parent.unit;
                        parent.u.Show();
                        parent.u.Location = new Point(0, 0);
                    }
                    if (i == 3)
                    {
                        MessageBox.Show("Shop");
                    }
                }
            }
        }
    }
}
