﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClassLibrary1;

namespace BraveFrontier
{
    public partial class Form1 : Form
    {
        public List<Units> unit;
        public Home h;
        public Quest q;
        public Unit u;
        public int stage;
        public int ministage;
        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.None;
            unit = new List<Units>();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            h = new Home();
            h.MdiParent = this;
            h.Show();
            h.Location = new Point(0, 0);
            Units newunit = new Units(Image.FromFile("Icons/excaliburicon.png"), Image.FromFile("Icons/Excalibur.png"));
            unit.Add(newunit);
        }
    }
}
